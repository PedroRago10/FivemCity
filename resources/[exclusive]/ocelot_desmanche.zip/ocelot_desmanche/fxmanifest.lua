fx_version 'cerulean'
game 'gta5'

author 'bfmjoao at Back-End'
contact 'discord.gg/TwuEPcKXvr - Ocelot Development'

shared_scripts {
	'ocelot.lua',
	'dev_functions.lua',
	'config.lua',
}

server_scripts {
	'server.lua',
}

client_scripts {
	'client.lua',
}