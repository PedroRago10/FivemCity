vRP = Proxy.getInterface('vRP')

-- Server
getUId = function(source)
    return vRP.getUserId(source)
end

giveInvItem = function(source,item,amount)
    return vRP.giveInventoryItem(getUId(source),item,amount)
end

getInvItemAmount = function(source,item)
    return vRP.getInventoryItemAmount(getUId(source),item)
end

tryGetInvItem = function(source,item,amount)
    return vRP.tryGetInventoryItem(getUId(source),item,amount)
end

checkPermission = function(source,permission)
    return vRP.hasPermission(getUId(source),permission)
end

getUserByRegist = function(registration,source)
    return vRP.getUserByRegistration(registration)
end

giveMoney = function(source,amount)
    return vRP.giveMoney(getUId(source),amount)
end

setDestroyed = function(bool,veh,plate)
	MySQL.Async.execute('UPDATE owned_vehicles SET impound=@impound WHERE plate=@plate',
	{ impound = 1, plate = plate, vehicle = veh })
end

-- Client
getVehInfo = function(veh)
    local vehLoweredName,plateTextVeh = GetDisplayNameFromVehicleModel(GetEntityModel(veh)):lower(),GetVehicleNumberPlateText(veh)
    return vehLoweredName,plateTextVeh
end

local anims = {}
local anim_ids = Tools.newIDGenerator()

stopAnim = function(upper)
	anims = {}
	if upper then
		ClearPedSecondaryTask(PlayerPedId())
	else
		ClearPedTasks(PlayerPedId())
	end
end

playAnim = function(upper,seq,looping)
	stopAnim(upper)

	local flags = 0
	if upper then flags = flags+48 end
	if looping then flags = flags+1 end

	CreateThread(function()
		local id = anim_ids:gen()
		anims[id] = true

		for k,v in next,seq do
			local dict = v[1]
			local name = v[2]
			local loops = v[3] or 1

			for i=1,loops do
				if anims[id] then
					local first = (k == 1 and i == 1)
					local last = (k == #seq and i == loops)

					RequestAnimDict(dict)
					local i = 0
					while not HasAnimDictLoaded(dict) and i < 1000 do
					Wait(10)
					RequestAnimDict(dict)
					i = i + 1
				end

				if HasAnimDictLoaded(dict) and anims[id] then
					local inspeed = 3.0
					local outspeed = -3.0
					if not first then inspeed = 2.0 end
					if not last then outspeed = 2.0 end

					TaskPlayAnim(PlayerPedId(),dict,name,inspeed,outspeed,-1,flags,0,0,0,0)
				end
					Wait(1)
					while GetEntityAnimCurrentTime(PlayerPedId(),dict,name) <= 0.95 and IsEntityPlayingAnim(PlayerPedId(),dict,name,3) and anims[id] do
						Wait(1)
					end
				end
			end
		end
		anim_ids:free(id)
		anims[id] = nil
	end)
end

getNearestVehicles = function(radius)
	local r = {}
	local px,py,pz = table.unpack(GetEntityCoords(PlayerPedId()))

	local vehs = {}
	local it,veh = FindFirstVehicle()
	if veh then
		table.insert(vehs,veh)
	end
	local ok
	repeat
		ok,veh = FindNextVehicle(it)
		if ok and veh then
			table.insert(vehs,veh)
		end
	until not ok
	EndFindVehicle(it)

	for _,veh in pairs(vehs) do
		local x,y,z = table.unpack(GetEntityCoords(veh))
		local distance = Vdist(x,y,z,px,py,pz)
		if distance <= radius then
			r[veh] = distance
		end
	end
	return r
end