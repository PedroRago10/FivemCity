Config = {}

-- Token enviado por nossa equipe após a compra ser confirmada.
Config.accessToken = 'token'

-- Adicione múltiplos locais onde o desmanche estará funcionando, basta seguir os exemplos deixados na tabela.
Config.dismantlePoints = {
    [1] = { 
        ['dismantleCoords'] = { 833.36,-803.45,26.29 }, -- Coordenadas do ponto de desmanche;
        ['tableCoords'] = { 834.19,-797.29,26.3 }, -- Coordenadas da mesa desse ponto de desmanche;
        ['permissions'] = { 'admin.permissao' }, -- false = Nenhuma permissão necessária;
        ['useDirtMoney'] = true, -- Utilizar ou não dinheiro sujo;
        ['useDrawMarkerBlip'] = true, -- Ative essa opção caso queira que o blip rodando no chão apareça;
            ['drawMarkerModel'] = 27, -- Escolha o modelo de marker do blip;
            ['drawMarkerColours'] = { 255, 137, 0 }, -- Escolha as cores em RGB que o blip terá caso estiver ativado;
        ['textColour'] = 'o',
     },
     [2] = { 
        ['dismantleCoords'] = { 833.36,-803.45,26.29 }, -- Coordenadas do ponto de desmanche;
        ['tableCoords'] = { 834.19,-797.29,26.3 }, -- Coordenadas da mesa desse ponto de desmanche;
        ['permissions'] = { 'admin.permissao' }, -- false = Nenhuma permissão necessária;
        ['useDirtMoney'] = true, -- Utilizar ou não dinheiro sujo;
        ['useDrawMarkerBlip'] = true, -- Ative essa opção caso queira que o blip rodando no chão apareça;
            ['drawMarkerModel'] = 27, -- Escolha o modelo de marker do blip;
            ['drawMarkerColours'] = { 255, 137, 0 }, -- Escolha as cores em RGB que o blip terá caso estiver ativado;
        ['textColour'] = 'o',
     },
}

-- Escolha se um jogador poderá desmanchar o próprio veículo ou não;
Config.autoChop = true

-- Escolha a quantia de dinheiro que o jogador ganhará ao fim do desmanche de acordo com cada tipo de veículo.
Config.paymentValues = {
    ['veh4'] = { 5200, 5733 }, -- Veículos 4 portas;
    ['veh2'] = { 4500, 4750 }, -- Veículos 2 portas;
    ['moto'] = { 2500, 2750 }, -- Motos;
}

-- Lista de veículos únicos com valores de pagamento personalizados;
Config.vehiclePrices = {
    ['nissangtr'] = 17330,
    ['ferrari458'] = 17330,
    ['corvettec8'] = 17330,
    ['bmwm5'] = 17330,
}

-- Ative essa opção caso queira que o jogador receba itens ao fim do desmanche.
Config.receiveItems = true
    -- Caso a opção acima esteja ativada, escolha agora os itens que serão ganhos por cada tipo de veículo;
    Config.itemsToReceive = {
        ['veh4'] = { -- Veículos 4 portas;
            { 'porta', 4 },
            { 'bateria', 1 },
            { 'carburador', 1 },
            { 'caixacambio', 1 },
        },
        ['veh2'] = { -- Veículos 2 portas;
            { 'porta', 2 },
            { 'bateria', 1 },
            { 'carburador', 1 },
            { 'caixacambio', 1 },
        },
        ['moto'] = { -- Motos;
            { 'escapamento', 1 },
            { 'bateria', 1 },
            { 'pneu', 2 },
        }
    }

-- Ative essa opção caso queira usar de progressbars durante o desmanche.
Config.useProgressBar = true

-- Escolha as mensagens que serão exibidas nas notifys de acordo com cada situação.
Config.msgsNotify = {
    ['noPerm'] = 'Você não tem permissão para realizar um desmanche!', -- Sem permissão para iniciar;
    ['badVehClass'] = 'Você não pode desmanchar esse tipo de veículo.', -- Tipo de veículo não aceito no desmanche (Ex: Caminhões);
    ['badAutoChop'] = 'Você não pode desmanchar seu próprio veículo!', -- Erro ao tentar desmanchar o próprio veículo;
    ['finishDismantle'] = 'Desmanche finalizado! Você recebeu R$', -- O desmanche terminou, e quanto o player ganhou naquele momento;
    ['cancelByDistance'] = 'Se continuar se afastando o desmanche será cancelado e o veículo perdido.', -- Caso o player comece a sair de perto do veículo;
    ['canceledDismantle'] = 'O desmanche foi interrompido e o veículo levado pela polícia.', -- Caso o jogador vá longe demais e o desmanche seja cancelado;
}

-- Webhooks para logs do desmanche;
Config.webHooks = {
    ['started'] = 'link', -- Iniciou um desmanche;
    ['finished'] = 'link', -- Finalizou um desmanche;
    ['cancel'] = 'link', -- Cancelou um desmanche;
    ['autoChop'] = 'link', -- Tentou desmanchar o próprio veículo;
}







---------------------------------------------------------------------------------------------------------
-- Aviso: Só mude algo abaixo caso entenda do que se trata, se não vai dar merd*.
---------------------------------------------------------------------------------------------------------
Config.sql = {
    ['vehicles'] = 'vrp_user_vehicles',
    ['dismantle'] = 'detido',
    ['uid'] = 'user_id',
    ['veh'] = 'vehicle',
    ['bolnum'] = 1,
}